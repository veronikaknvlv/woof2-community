import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Woof² — Кофе на районе",
  description: "Галерея моментов гостей Woof²",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="ru">
      <body>{children}</body>
    </html>
  );
}
