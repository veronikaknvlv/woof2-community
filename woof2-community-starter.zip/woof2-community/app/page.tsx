"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";

type Photo = {
  id: string;
  image_url: string;
  display_name: string | null;
  caption: string | null;
  likes_count: number;
  created_at: string;
};

export default function Home() {
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [name, setName] = useState("");
  const [caption, setCaption] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [message, setMessage] = useState("");
  const [sort, setSort] = useState<"new" | "popular">("new");

  async function loadPhotos() {
    const { data, error } = await supabase
      .from("photos")
      .select("id,image_url,display_name,caption,likes_count,created_at")
      .eq("status", "approved")
      .order(sort === "popular" ? "likes_count" : "created_at", { ascending: false })
      .limit(60);
    if (!error && data) setPhotos(data as Photo[]);
    setLoading(false);
  }

  useEffect(() => { loadPhotos(); }, [sort]);

  async function submitPhoto(e: React.FormEvent) {
    e.preventDefault();
    if (!file) { setMessage("Сначала выбери фотографию."); return; }
    if (!file.type.startsWith("image/")) { setMessage("Можно загрузить только изображение."); return; }
    if (file.size > 8 * 1024 * 1024) { setMessage("Файл должен быть не больше 8 МБ."); return; }

    setUploading(true);
    setMessage("");
    const safeName = file.name.toLowerCase().replace(/[^a-z0-9._-]/g, "-");
    const path = `${crypto.randomUUID()}-${safeName}`;
    const { error: uploadError } = await supabase.storage.from("guest-photos").upload(path, file, {
      cacheControl: "3600", upsert: false, contentType: file.type
    });
    if (uploadError) {
      setMessage("Не удалось загрузить фото. Проверьте настройки хранилища.");
      setUploading(false); return;
    }
    const { data: publicData } = supabase.storage.from("guest-photos").getPublicUrl(path);
    const { error: insertError } = await supabase.from("photos").insert({
      image_url: publicData.publicUrl,
      storage_path: path,
      display_name: name.trim() || null,
      caption: caption.trim() || null,
      status: "pending"
    });
    if (insertError) {
      setMessage("Фото загрузилось, но не отправилось на проверку. Попробуйте позже.");
    } else {
      setMessage("Спасибо! Фото отправлено на проверку и появится в галерее после одобрения.");
      setFile(null); setName(""); setCaption("");
      const input = document.getElementById("photo-file") as HTMLInputElement | null;
      if (input) input.value = "";
    }
    setUploading(false);
  }

  async function likePhoto(photo: Photo) {
    let voter = localStorage.getItem("woof2-voter");
    if (!voter) {
      voter = crypto.randomUUID();
      localStorage.setItem("woof2-voter", voter);
    }
    const { error } = await supabase.rpc("like_photo", { p_photo_id: photo.id, p_voter_key: voter });
    if (!error) setPhotos(current => current.map(p => p.id === photo.id ? { ...p, likes_count: p.likes_count + 1 } : p));
    else setMessage("Не удалось поставить лайк. Возможно, вы уже голосовали за это фото.");
  }

  return (
    <main className="page">
      <header className="brand">
        <div className="logo">Woof<span>²</span></div>
        <div className="tagline">КОФЕ НА РАЙОНЕ</div>
        <p className="intro">Моменты, которыми хочется поделиться ☕</p>
      </header>

      <section className="upload-card">
        <div>
          <p className="eyebrow">ТВОЙ МОМЕНТ В WOOF²</p>
          <h1>Добавь фото в нашу галерею</h1>
          <p className="muted">Покажи любимый напиток, друзей или атмосферу кофейни. Публикация появится после проверки.</p>
        </div>
        <form onSubmit={submitPhoto} className="upload-form">
          <label className="file-label" htmlFor="photo-file">＋ Выбрать фотографию</label>
          <input id="photo-file" type="file" accept="image/*" onChange={e => setFile(e.target.files?.[0] || null)} />
          {file && <p className="file-name">{file.name}</p>}
          <input value={name} onChange={e => setName(e.target.value)} maxLength={32} placeholder="Имя или ник (необязательно)" />
          <textarea value={caption} onChange={e => setCaption(e.target.value)} maxLength={180} placeholder="Подпись к фото (необязательно)" rows={2} />
          <button disabled={uploading}>{uploading ? "Отправляем…" : "Отправить на проверку"}</button>
          <p className="fine">До 8 МБ. Загружая фото, вы подтверждаете, что имеете право его публиковать и согласны с правилами галереи.</p>
          {message && <p className="notice" role="status">{message}</p>}
        </form>
      </section>

      <section className="gallery-head">
        <div><p className="eyebrow">СООБЩЕСТВО WOOF²</p><h2>Галерея гостей</h2></div>
        <div className="sort">
          <button className={sort === "new" ? "active" : ""} onClick={() => setSort("new")}>Новые</button>
          <button className={sort === "popular" ? "active" : ""} onClick={() => setSort("popular")}>Популярные</button>
        </div>
      </section>

      {loading ? <p className="muted">Загружаем галерею…</p> :
        photos.length === 0 ? <div className="empty"><span>☕</span><h3>Здесь скоро появятся ваши моменты</h3><p>Станьте первым — добавьте фотографию Woof².</p></div> :
        <section className="grid">
          {photos.map(photo => <article className="photo-card" key={photo.id}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={photo.image_url} alt={photo.caption || "Фото гостя Woof²"} />
            <div className="photo-meta">
              <div><strong>{photo.display_name || "Гость Woof²"}</strong>{photo.caption && <p>{photo.caption}</p>}</div>
              <button className="like" onClick={() => likePhoto(photo)} aria-label="Поставить лайк">♡ <span>{photo.likes_count}</span></button>
            </div>
          </article>)}
        </section>
      }
      <footer>Woof² · Кофе на районе</footer>
    </main>
  );
}
