-- 1) Create a public storage bucket for guest photos.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('guest-photos', 'guest-photos', true, 8388608, array['image/jpeg','image/png','image/webp','image/heic'])
on conflict (id) do nothing;

-- 2) Photos table. New submissions are pending and are not shown in the public gallery.
create table if not exists public.photos (
  id uuid primary key default gen_random_uuid(),
  image_url text not null,
  storage_path text not null,
  display_name text,
  caption text,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  likes_count integer not null default 0 check (likes_count >= 0),
  created_at timestamptz not null default now()
);

create table if not exists public.photo_likes (
  id uuid primary key default gen_random_uuid(),
  photo_id uuid not null references public.photos(id) on delete cascade,
  voter_key text not null,
  created_at timestamptz not null default now(),
  unique(photo_id, voter_key)
);

alter table public.photos enable row level security;
alter table public.photo_likes enable row level security;

-- Anyone can view approved photos only.
create policy "Public can view approved photos" on public.photos
for select using (status = 'approved');

-- Anyone can submit a photo, but it always enters pending moderation.
create policy "Anyone can submit pending photos" on public.photos
for insert with check (
  status = 'pending'
  and length(coalesce(display_name,'')) <= 32
  and length(coalesce(caption,'')) <= 180
);

-- Public uploads to the guest-photos bucket. Restrict file size and type in bucket settings too.
create policy "Anyone can upload guest photos" on storage.objects
for insert to anon, authenticated
with check (bucket_id = 'guest-photos');

-- Atomic like function: one like per photo per browser-generated voter key.
create or replace function public.like_photo(p_photo_id uuid, p_voter_key text)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if length(p_voter_key) < 16 or length(p_voter_key) > 80 then
    raise exception 'Invalid voter key';
  end if;

  insert into public.photo_likes(photo_id, voter_key)
  select p_photo_id, p_voter_key
  where exists (
    select 1 from public.photos where id = p_photo_id and status = 'approved'
  )
  on conflict (photo_id, voter_key) do nothing;

  update public.photos
  set likes_count = (
    select count(*) from public.photo_likes where photo_id = p_photo_id
  )
  where id = p_photo_id and status = 'approved';
end;
$$;

grant execute on function public.like_photo(uuid, text) to anon, authenticated;
grant select on public.photos to anon, authenticated;
grant insert on public.photos to anon, authenticated;
grant insert on storage.objects to anon, authenticated;
